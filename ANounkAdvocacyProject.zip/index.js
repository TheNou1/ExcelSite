let themeButton = document.getElementById("theme-button");
const toggleDarkMode = () => {
  document.body.classList.toggle("dark-mode");
}
themeButton.addEventListener("click", toggleDarkMode);


// Petition form

let signNowButton = document.getElementById("sign-now-button")
const addSignature = () => {
  const name = document.getElementById("name").value;
  const lastname = document.getElementById("lastname").value;
  const hometown = document.getElementById("town").value;
  const email = document.getElementById("email").value;
  const signatures = document.querySelector(".signatures");
  const newSignature = document.createElement("p");
  newSignature.textContent = `️${name} ${lastname} from ${hometown} supports this.`;
  signatures.appendChild(newSignature);
  
}
  // TODO: Remove the click event listener that calls addSignature()

  // TODO: Complete validation form

  const validateForm = () => {
    
    let containsErrors = false;

    var petitionInputs = document.getElementById("sign-petition").elements;
    for(let i = 0;i < petitionInputs.length; i++) {
      if(petitionInputs[i].value.length < 2){ 
        petitionInputs[i].classList.add('error')
        containsErrors = true;

      }
      else{
        petitionInputs[i].classList.remove('error')
      }
    }
    if(containsErrors == false){
      addSignature();
      for(i = 0; i < petitionInputs.length; i++){
        petitionInputs[i].value = "";
        containsErrors = false;
      }
    }

  }

  signNowButton.addEventListener('click', validateForm);
let animation = {
  revealDistance: 150,
  initialOpacity: 0,
  transitionDelay: 0,
  transitionDuration: '2s',
  transitionProperty: 'all',
  transitionTimingFunction: 'ease'
}
