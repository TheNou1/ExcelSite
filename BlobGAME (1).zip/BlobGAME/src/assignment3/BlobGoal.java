package assignment3;

import java.awt.Color;

public class BlobGoal extends Goal {

    public BlobGoal(Color c) {
        super(c);
    }

    @Override
    public int score(Block board) {

        Color[][] unitCells = board.flatten();
        int biggestBlob = 0;
        boolean[][] visited = new boolean[unitCells.length][unitCells.length];
        for(int x = 0, y=0; x < unitCells.length; x++, y++ ){
            int blobSize = undiscoveredBlobSize(x,y,unitCells,visited);
            if(biggestBlob < blobSize){

                biggestBlob = blobSize;

            }
        }
        return biggestBlob;
    }

    @Override
    public String description() {
        return "Create the largest connected blob of " + GameColors.colorToString(targetGoal)
                + " blocks, anywhere within the block";
    }


    public int undiscoveredBlobSize(int i, int j, Color[][] unitCells, boolean[][] visited) {
        int size = 0;
        if(i >= unitCells.length|| i<0|| j<0 || j>= unitCells.length){return 0;}

        if(targetGoal != unitCells[i][j] || visited[i][j]){return 0;}
        else{
            size++;
            visited[i][j] = true;

            size += undiscoveredBlobSize(i+1,j,unitCells,visited);
            size += undiscoveredBlobSize(i-1,j,unitCells,visited);
            size += undiscoveredBlobSize(i,j+1,unitCells,visited);
            size += undiscoveredBlobSize(i,j-1,unitCells,visited);

        }
        return size;

    }

}
