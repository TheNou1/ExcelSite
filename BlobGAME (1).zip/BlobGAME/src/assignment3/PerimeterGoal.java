package assignment3;



import java.awt.Color;

public class PerimeterGoal extends Goal {

    public PerimeterGoal(Color c) {
        super(c);
    }

    @Override
    public int score(Block board) {
        Color[][] colors = board.flatten();
        int score = 0;
        for (int j = 0; j < colors[0].length; j++) {
            if(colors[0][j]  == targetGoal){
                score++;
            }
            else if(colors[colors.length-1][j]  == targetGoal){
                score++;
            }
        }
        for (int j = 0; j < colors[0].length; j++) {
            if(colors[j][0]  == targetGoal){
                score++;

            }
            if(colors[j][colors[0].length-1]  == targetGoal){
                score++;

            }
        }
        return score;
    }

    @Override
    public String description() {
        return "Place the highest number of " + GameColors.colorToString(targetGoal)
                + " unit cells along the outer perimeter of the board. Corner cell count twice toward the final score!";
    }

}
