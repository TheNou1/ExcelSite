#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <math.h>
#include <stdbool.h>// do i need to use the actual true and false or should i just print it?
// do i use exit() or return for exit code?
int gcd(int a, int b){

        while (b != 0){ int temp = b;
                        b = a%b;
                        a = temp;
                        }
        return a;}
int isAnagram(const char *S1, const char *S2) {


    // validating string lenghts
    if(strlen(S1) != strlen(S2)){
    return false;}

    // making character arrays
    int S1chars[26] = {0};
    int S2chars[26] = {0};

    for (int i = 0; S1[i] && S2[i]; i++) {
    S1chars[S1[i] - 97]++;
    S2chars[S2[i] - 97]++;
  }
   // Comparing character counts
   for (int i = 0; i < 26; i++) {
     if (S1chars[i] != S2chars[i]) {
       return false;}}

   return true;}


int main(int argc, char *argv[]){
//error handling
	// # of args	
	if(argc < 2){
	        fprintf(stderr, "Error: Minicalc requires at least one command-line argument.\n");
		return 1;
	}
	// do the index make sense?	
	char *func = argv[1];


    	if ( strcmp(func, "+") != 0 && strcmp(func, "gcd") != 0 && strcmp(func, "sqrt") != 0 && strcmp(func, "anagram")!= 0) {
        fprintf(stderr, "Error: The first command-line argument must specify one of the allowed operations.\n");
        return 2;
    }
        // case specific # of args initializer
   	int expectedArgs;

	// using the functions
	//GCD

	if(strcmp(func, "gcd") == 0){
		
		// error handling
		
		// argument count checking
		if(argc < 4){fprintf(stderr, "Error: Incorrect number of arguments for the specified operation.\n"); return 3;}	
		
		// nonnegative check
		for(int i = 2; i< argc; i++){
		if(atoi(argv[i]) < 0){
			fprintf(stderr, "Error: GCD function only accepts positive integers\n");
			return 7;}}
		
		// create an array of the inputs and check all of them individually in one loop
		char numbers[argc-2];
		for(int i=2; i<argc; i++){
		char *endptr;
		long int num1 = strtol(argv[2], &endptr, 10);
		if (*endptr != '\0') {   
		fprintf(stderr, "Error: GCD function only accepts valid integers\n");
		return 4;}
		} 
		
		int result = atoi(argv[2]);

	 	// Loop through the remaining integers and find the GCD with the result
	    	for (int i = 3; i < argc; i++) {
	    	    int currentInt = atoi(argv[i]);
	    	    result = gcd(result, currentInt);
	    	}
		printf("%d\n",result);	
		return result;}


	



	//SQRT - check for exit code
	 else if(strcmp(func, "sqrt") == 0){
		
	 	//error handling
		// exit code 3
		expectedArgs = 3;
		if(argc != expectedArgs){fprintf(stderr, "Error: Incorrect number of arguments for the specified operation.\n"); return 3;}
		
		//exit code 4
		char *endptr;
        	double number = strtod(argv[2], &endptr);

        	if (*endptr != '\0') {
           	fprintf(stderr, "Error: SQRT function only accepts positive doubles\n");
          	return 4;
        	}
		
		//exit code 5
	 	if(strtod(argv[2], NULL) < 0){
              	fprintf(stderr, "Error: SQRT function only accepts positive numbers\n");return 5;}
	 	
		//using sqrt
		double newNumber = strtod(argv[2],NULL);// is this necessary? what's the type of the input?
		printf("%f\n",sqrt(newNumber));
		return	sqrt(newNumber);}
	
	//Anagrams
	
	else if(strcmp(func, "anagram") == 0){
		expectedArgs = 4;
		
		//error handling 
		if(argc != expectedArgs){fprintf(stderr, "Error: Incorrect number of arguments for the specified operation.\n"); return 3;}
		//kinda buggy idk
		for (int i = 0; argv[2][i] != '\0'; i++) {
        	if (!(argv[2][i] >= 'a' && argv[2][i] <= 'z')) {
                	fprintf(stderr, "Error: Anagram function only accept lowercase letters\n");
                	return 6;}

		// error handling for S2 (is this necessary? is there a better way?)
		for (int i = 0; argv[3][i] != '\0'; i++) {
                if (!(argv[3][i] >= 'a' && argv[3][i] <= 'z')) {
                        fprintf(stderr, "Error: Anagram function only accept lowercase letters\n");
                        return 6;}}

		// using the anagram funtion
		printf("%d\n",isAnagram(argv[2],argv[3]) );
		return isAnagram(argv[2],argv[3]);
		}

	// Add

	}else if(strcmp(func, "+") == 0){
		
		// Error handling
        	// exit code 3
        	expectedArgs = 4;

        	if(argc != expectedArgs){fprintf(stderr, "Error: Incorrect number of arguments for the specified operation.\n"); return 3;}

        	//exit code 4
        	char *endptr1, *endptr2;
        	long int operand1 = strtol(argv[2], &endptr1, 10);
        	long int operand2 = strtol(argv[3], &endptr2, 10);

        	if (*endptr1 != '\0' || *endptr2 != '\0') {
        	    fprintf(stderr, "Error: Addition function only accepts integers\n");
        	    return 4;
        	}
		// use add
		printf("%d\n", atoi(argv[2]) + atoi(argv[3]) );

		return atoi(argv[2]) + atoi(argv[3]);
	}}
