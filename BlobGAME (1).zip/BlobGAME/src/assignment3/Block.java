package assignment3;

import java.util.ArrayList;
import java.util.Random;
import java.awt.Color;

public class Block {


    private int xCoord;

    private int yCoord;
    private int size; // height/width of the square
    private int level; // the root (outer most block) is at level 0
    private int maxDepth;
    private Color color;

    private Block[] children; // {UR, UL, LL, LR}

    public static Random gen = new Random();

    public static void main(String[] args) {


        Block testBoard = new Block(0,2);
        testBoard.printBlock();


    }
    /*
     * These two constructors are here for testing purposes.
     */
    public Block() {}

    public Block(int x, int y, int size, int lvl, int  maxD, Color c, Block[] subBlocks) {
        this.xCoord=x;
        this.yCoord=y;
        this.size=size;
        this.level=lvl;
        this.maxDepth = maxD;
        this.color=c;
        this.children = subBlocks;
    }



    /*
     * Creates a random block given its level and a max depth.
     *
     * xCoord, yCoord, size, and highlighted should not be initialized
     * (i.e. they will all be initialized by default)
     */
        private void subDivide(Block b1) {
        if((b1.level == b1.maxDepth)){b1.children = new Block[0];
            b1.color = GameColors.BLOCK_COLORS[gen.nextInt(4)]; return;}
            //Subdivision  check
            Double test = gen.nextDouble();
            Double pass = Math.exp(-0.25*(b1.level));
            // recursive call
            if((test < pass)) {

            b1.children = new Block[4];
            for(int i =0; i< 4; i++) {
                Block dividedChild = new Block(0, 0, 0, b1.level + 1, b1.maxDepth, null, null);
                subDivide(dividedChild);
                b1.children[i] = dividedChild;
                }
            }
            else{b1.children = new Block[0];
                b1.color = GameColors.BLOCK_COLORS[gen.nextInt(4)];
            }

        }





    public Block(int lvl, int maxDepth) {
        this.xCoord=0;
        this.yCoord=0;
        this.size=0;
        this.level= lvl;
        this.maxDepth = maxDepth;
        this.color=null;
        this.children = new Block[4];
        subDivide(this);


    }


    /*
     * Updates size and position for the block and all of its sub-blocks, while
     * ensuring consistency between the attributes and the relationship of the
     * blocks.
     *
     *  The size is the height and width of the block. (xCoord, yCoord) are the
     *  coordinates of the top left corner of the block.
     */
    public void updateSizeAndPosition (int size, int xCoord, int yCoord) {
        if(size < 0 || size % 2 != 0){throw new IllegalArgumentException("Invalid size argument");}

        double unitCellSize = size;

        for(int i= level; i<maxDepth; i++){
            unitCellSize = unitCellSize/2;
        }

        double check = size%unitCellSize;

        if(check != 0){
            throw new IllegalArgumentException("Invalid size argument");
        }

        this.size = size;
        this.xCoord = xCoord;
        this.yCoord = yCoord;
        this.updateHelper(size,xCoord,yCoord);
    }
    private void updateHelper(int size, int xCoord, int yCoord){
        if(this.children.length == 0){
            this.size = size;
            this.xCoord = xCoord;
            this.yCoord = yCoord;
        }
        else{
            this.size = size;
            this.xCoord = xCoord;
            this.yCoord = yCoord;

            this.children[0].updateHelper(size/2,xCoord + size/2,yCoord);
            this.children[1].updateHelper(size/2,xCoord,yCoord);
            this.children[2].updateHelper(size/2,xCoord,yCoord+ size/2);
            this.children[3].updateHelper(size/2,xCoord+size/2,yCoord+size/2);


        }
    }


    /*
     * Returns a List of blocks to be drawn to get a graphical representation of this block.
     *
     * This includes, for each undivided Block:
     * - one BlockToDraw in the color of the block
     * - another one in the FRAME_COLOR and stroke thickness 3
     *
     * Note that a stroke thickness equal to 0 indicates that the block should be filled with its color.
     *
     * The order in which the blocks to draw appear in the list does NOT matter.
     */
    public ArrayList<BlockToDraw> getBlocksToDraw() {
        return BlocksToDraw(this);

    }
    public ArrayList<BlockToDraw> BlocksToDraw(Block b1) {
        if(b1.children.length == 0){
            BlockToDraw fill = new BlockToDraw(b1.color, b1.xCoord, b1.yCoord, b1.size,0);
            BlockToDraw frame = new BlockToDraw(GameColors.FRAME_COLOR, b1.xCoord, b1.yCoord, b1.size,3);
            ArrayList<BlockToDraw> pair = new ArrayList<BlockToDraw>();
            pair.add(fill);
            pair.add(frame);
            return pair;
        }
        else{
            ArrayList<BlockToDraw> result = new ArrayList<BlockToDraw>();
            for(int i = 0;i < 4; i++){
                result.addAll(BlocksToDraw(b1.children[i]));
            }
            return result;


        }


    }

    /*
     * This method is provided and you should NOT modify it.
     */
    public BlockToDraw getHighlightedFrame() {
        return new BlockToDraw(GameColors.HIGHLIGHT_COLOR, this.xCoord, this.yCoord, this.size, 5);
    }



    /*
     * Return the Block within this Block that includes the given location
     * and is at the given level. If the level specified is lower than
     * the lowest block at the specified location, then return the block
     * at the location with the closest level value.
     *
     * The location is specified by its (x, y) coordinates. The lvl indicates
     * the level of the desired Block. Note that if a Block includes the location
     * (x, y), and that Block is subdivided, then one of its sub-Blocks will
     * contain the location (x, y) too. This is why we need lvl to identify
     * which Block should be returned.
     *
     * Input validation:
     * - this.level <= lvl <= maxDepth (if not throw exception)
     * - if (x,y) is not within this Block, return null.
m     */
    public Block getSelectedBlock(int x, int y, int selectedLevel) {
        // Input validation: Check if selectedLevel is within bounds
        if (selectedLevel < level || selectedLevel > maxDepth) {
            throw new IllegalArgumentException("Selected level is out of bounds.");
        }

        // Check if the position is within this block
        if (!containsPoint(x, y)) {
            return null; // Coordinates are not within the current block bounds
        }

        // If this block is at the selected level, return this block
        if (level == selectedLevel) {
            return this;
        }

        // Find the closest child block

        System.out.println(children.length);
        for (Block child : children) {
            if (child.containsPoint(x, y)) {
                return child.getSelectedBlock(x,y,selectedLevel);



            }
        }



        // If this block is not at the selected level and it doesn't have children, return this block
        return this;
    }









    private boolean containsPoint(int x, int y) {
        return (x >= xCoord && x < xCoord + size) && (y >= yCoord && y < yCoord + size);
    }




    /*
     * Swaps the child Blocks of this Block.
     * If input is 1, swap vertically. If 0, swap horizontally.
     * If this Block has no children, do nothing. The swap
     * should be propagate, effectively implementing a reflection
     * over the x-axis or over the y-axis.
     *
     */
    public void reflect(int direction) {
        this.reflection(direction);
        this.updateSizeAndPosition(size,xCoord,yCoord);
    }
    public void reflection(int direction){
    if(direction != 1 && direction != 0) {
        throw new IllegalArgumentException("Invalid direction input. Expected 0 or 1.");
    }
    // If this block has no children, do nothing
    if (children.length == 0) {
        return;
    }
    if(level != maxDepth){

    // Swap the child blocks vertically (along the x-axis)
    Block temp = children[0];
    if (direction == 0) {

        children[0] = children[3];
        children[3] = temp;
        swapCoords(children[0], children[3]);
        temp = children[1];
        children[1] = children[2];
        children[2] = temp;
        swapCoords(children[1], children[2]);


    }
    // Swap the child blocks horizontally (along the y-axis)
    else {
        children[0] = children[1];
        children[1] = temp;
        swapCoords(children[0], children[1]);
        temp = children[2];
        children[2] = children[3];
        children[3] = temp;
        swapCoords(children[2], children[3]);


    }
    for(Block child:children){
        child.reflection(direction);
    }}

}

    private void swapCoords(Block b1, Block b2) {
        int TempX  = b1.xCoord;
        int TempY = b1.yCoord;
        b1.yCoord = b2.yCoord;
        b1.xCoord = b2.xCoord;
        b2.xCoord = TempX;
        b2.yCoord = TempY;
    }


    /*
     * Rotate this Block and all its descendants.
     * If the input is 1, rotate clockwise. If 0, rotate
     * counterclockwise. If this Block has no children, do nothing.
     */
    public void rotate(int direction) {
        this.rotation(direction);
        this.updateSizeAndPosition(size,xCoord,yCoord);
    }
    private void rotation(int direction){
        if(direction != 0 && direction != 1){
            throw new IllegalArgumentException("ILLEGALL ARRRRRGUMENT");}
        if (children.length == 0) {
            return;}
        if(level != maxDepth) {
            if (direction == 1) {
                Block firstElement = children[0];

                for (int i = 0; i < children.length - 1; i++) {
                    swapCoords(children[i], children[i + 1]);
                    children[i] = children[i + 1];
                }
                children[children.length - 1] = firstElement;}
            else {
                Block lastElement = children[children.length - 1];
                for (int i = children.length - 1; i > 0; i--) {
                    swapCoords(children[i-1], children[i]);
                    children[i] = children[i - 1];
                }
                children[0] = lastElement;
            }
            for(Block child:children){
                child.rotation(direction);
                System.out.println("rotated");
            }

        }
    }



    /*
     * Smash this Block.
     *
     * If this Block can be smashed,
     * randomly generate four new children Blocks for it.
     * (If it already had children Blocks, discard them.)
     * Ensure that the invariants of the Blocks remain satisfied.
     *
     * A Block can be smashed iff it is not the top-level Block
     * and it is not already at the level of the maximum depth.
     *
     * Return True if this Block was smashed and False otherwise.
     *
     */
    public boolean smash() {
        /*
         * smash doesnt split into 4 equal blocks, it splits into blocks\
         *  that may or may not also have children
         * use Block(level,MaxDepth) to generate it and keep going until maxdepth is reached   */
        if(level == maxDepth || level == 0){
            return false;
        }
        this.children = new Block[4];
        for(int i= 0; i<4; i++){
            children[i] = new Block(level+1,maxDepth);
        }
        this.updateHelper(size,xCoord,yCoord);
        return true;
    }



    /*
     * Return a two-dimensional array representing this Block as rows and columns of unit cells.
     *
     * Return and array arr where, arr[i] represents the unit cells in row i,
     * arr[i][j] is the color of unit cell in row i and column j.
     *
     * arr[0][0] is the color of the unit cell in the upper left corner of this Block.
     */
    public Color[][] flatten() {
        // can array be bigger than colors? how big should it be?
        Color[][] result =  new Color[(int)(Math.pow(2,maxDepth-level)) ][(int)(Math.pow(2,maxDepth-level))];
        double unitCellSize = size;
        for(int i= level; i<maxDepth; i++){
            unitCellSize = unitCellSize/2;
        }
        fillArray(result,unitCellSize );
        return result;
    }
    private void fillArray(Color[][] arr, double unitCellSize){
        int unitCell = (int)(Math.pow(2,maxDepth-level));
        if(children.length==0){
            for(int x = (int) (xCoord/unitCellSize); x < unitCell+xCoord/unitCellSize; x++ ){
                for(int y = (int) (yCoord/unitCellSize); y < unitCell+yCoord/unitCellSize ; y++ ){
                    arr[y][x] = color;
                }
            }
        }
        else{
            for(Block child:children){
                child.fillArray(arr, unitCellSize);
            }
        }
    }

    // These two get methods have been provided. Do NOT modify them.
    public int getMaxDepth() {
        return this.maxDepth;
    }

    public int getLevel() {
        return this.level;
    }


    /*
     * The next 5 methods are needed to get a text representation of a block.
     * You can use them for debugging. You can modify these methods if you wish.
     */
    public String toString() {
        return String.format("pos=(%d,%d), size=%d, level=%d"
                , this.xCoord, this.yCoord, this.size, this.level);
    }

    public void printBlock() {
        this.printBlockIndented(0);
    }

    private void printBlockIndented(int indentation) {
        String indent = "";
        for (int i=0; i<indentation; i++) {
            indent += "\t";
        }

        if (this.children.length == 0) {
            // it's a leaf. Print the color!
            String colorInfo = GameColors.colorToString(this.color) + ", ";
            System.out.println(indent + colorInfo + this);
        } else {
            System.out.println(indent + this);
            for (Block b : this.children)
                b.printBlockIndented(indentation + 1);
        }
    }

    private static void coloredPrint(String message, Color color) {
        System.out.print(GameColors.colorToANSIColor(color));
        System.out.print(message);
        System.out.print(GameColors.colorToANSIColor(Color.WHITE));
    }

    public void printColoredBlock(){
        Color[][] colorArray = this.flatten();
        for (Color[] colors : colorArray) {
            for (Color value : colors) {
                String colorName = GameColors.colorToString(value).toUpperCase();
                if(colorName.length() == 0){
                    colorName = "\u2588";
                }else{
                    colorName = colorName.substring(0, 1);
                }
                coloredPrint(colorName, value);
            }
            System.out.println();
        }
    }

}


